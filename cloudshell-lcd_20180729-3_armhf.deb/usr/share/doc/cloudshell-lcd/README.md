# cloudshell_lcd
ODROID-XU4 Cloudshell LCD Informations for Server

Installation:

wget https://raw.githubusercontent.com/mdrjr/cloudshell_lcd/master/cloudshell-lcd_20150731-2_armhf.deb

sudo dpkg -i cloudshell-lcd_20150731-1_armhf.deb

sudo apt-get -f install

